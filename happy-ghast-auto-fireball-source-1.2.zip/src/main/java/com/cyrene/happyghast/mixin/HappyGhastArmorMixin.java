package com.cyrene.happyghast.mixin;

import com.cyrene.happyghast.HappyGhastAutoFireball;
import com.cyrene.happyghast.ModItems;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.happyghast.HappyGhast;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class HappyGhastArmorMixin {
    @Inject(method = "getAttributeValue", at = @At("RETURN"), cancellable = true)
    private void happyGhastArmor$addStoredArmor(Holder<Attribute> attribute, CallbackInfoReturnable<Double> cir) {
        if ((Object) this instanceof HappyGhast ghast) {
            if (attribute == Attributes.ARMOR) {
                cir.setReturnValue(cir.getReturnValue() + ModItems.armorPoints(HappyGhastAutoFireball.getArmor(ghast)));
            } else if (attribute == Attributes.FLYING_SPEED) {
                int level = ghast.getControllingPassenger() == null
                        ? 0 : HappyGhastAutoFireball.getFastFlightLevel(ghast);
                if (level > 0) {
                    cir.setReturnValue(cir.getReturnValue() * (1.0D + level));
                }
            }
        }
    }
}
