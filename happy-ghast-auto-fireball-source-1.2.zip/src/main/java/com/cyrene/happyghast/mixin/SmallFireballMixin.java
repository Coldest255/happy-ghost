package com.cyrene.happyghast.mixin;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.happyghast.HappyGhast;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Enderman;
import net.minecraft.world.entity.projectile.hurtingprojectile.SmallFireball;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SmallFireball.class)
public abstract class SmallFireballMixin {
    @Inject(method = "onHitEntity", at = @At("HEAD"), cancellable = true)
    private void happyGhastAutoFireball$dealFiveDamage(EntityHitResult hit, CallbackInfo ci) {
        SmallFireball projectile = (SmallFireball) (Object) this;
        Entity owner = projectile.getOwner();
        if (!(owner instanceof HappyGhast ghast)) {
            return;
        }

        Entity hitEntity = hit.getEntity();
        if (hitEntity instanceof LivingEntity target
                && !(target instanceof Player)
                && !(target instanceof Enderman)
                && target != owner
                && !target.isAlliedTo(owner)
                && projectile.level() instanceof ServerLevel serverLevel) {
            target.hurtServer(serverLevel,
                    serverLevel.damageSources().mobProjectile(projectile, ghast),
                    5.0F);
            target.igniteForSeconds(5.0F);
        }

        // Cancel vanilla fireball impact so it cannot ignite the target or blocks.
        projectile.discard();
        ci.cancel();
    }

    @Inject(method = "onHitBlock", at = @At("HEAD"), cancellable = true)
    private void happyGhastAutoFireball$preventBlockFire(BlockHitResult hit, CallbackInfo ci) {
        SmallFireball projectile = (SmallFireball) (Object) this;
        if (projectile.getOwner() instanceof HappyGhast) {
            projectile.discard();
            ci.cancel();
        }
    }
}
