package com.cyrene.happyghast.mixin;

import com.cyrene.happyghast.HappyGhastAutoFireball;
import com.cyrene.happyghast.OpenGhastStoragePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.animal.happyghast.HappyGhast;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(Minecraft.class)
public abstract class InventoryKeyMixin {
    @Shadow
    @Final
    public Options options;

    @Shadow
    public LocalPlayer player;

    @Redirect(
            method = "handleKeybinds",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/KeyMapping;consumeClick()Z", ordinal = 4)
    )
    private boolean betterHappyGhast$openMountedStorage(KeyMapping keyMapping) {
        boolean pressed = keyMapping.consumeClick();
        if (pressed && keyMapping == options.keyInventory && player != null
                && player.getVehicle() instanceof HappyGhast ghast) {
            ClientPlayNetworking.send(new OpenGhastStoragePayload(ghast.getId()));
            return false;
        }
        return pressed;
    }
}
