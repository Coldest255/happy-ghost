package com.cyrene.happyghast.mixin;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.happyghast.HappyGhast;
import net.minecraft.world.entity.monster.Phantom;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mob.class)
public abstract class PhantomTargetMixin {
    @Inject(method = "setTarget", at = @At("HEAD"), cancellable = true)
    private void betterHappyGhast$ignoreGhasts(LivingEntity target, CallbackInfo ci) {
        if ((Object) this instanceof Phantom && target instanceof HappyGhast) {
            ci.cancel();
        }
    }
}
