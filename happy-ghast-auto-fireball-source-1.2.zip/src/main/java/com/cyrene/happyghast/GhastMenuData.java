package com.cyrene.happyghast;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

public record GhastMenuData(int ghastId, int storageRows) {
    public static final StreamCodec<RegistryFriendlyByteBuf, GhastMenuData> CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, GhastMenuData::ghastId,
            ByteBufCodecs.VAR_INT, GhastMenuData::storageRows,
            GhastMenuData::new);
}
