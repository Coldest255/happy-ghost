package com.cyrene.happyghast;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.enchantment.Enchantable;

public final class ModItems {
    public static final Item CHEST_UPGRADE = register("happy_ghast_chest", new Item.Properties().stacksTo(1));
    public static final Item LEATHER_ARMOR = armor("leather_happy_ghast_armor");
    public static final Item COPPER_ARMOR = armor("copper_happy_ghast_armor");
    public static final Item IRON_ARMOR = armor("iron_happy_ghast_armor");
    public static final Item GOLDEN_ARMOR = armor("golden_happy_ghast_armor");
    public static final Item DIAMOND_ARMOR = armor("diamond_happy_ghast_armor");
    public static final Item NETHERITE_ARMOR = armor("netherite_happy_ghast_armor");

    private ModItems() {
    }

    public static void initialize() {
        // Referencing this class registers the item constants.
    }

    private static Item armor(String name) {
        return register(name, new Item.Properties().stacksTo(1)
                .component(DataComponents.ENCHANTABLE, new Enchantable(15)));
    }

    public static boolean isHappyGhastArmor(net.minecraft.world.item.ItemStack stack) {
        return stack.is(LEATHER_ARMOR) || stack.is(COPPER_ARMOR) || stack.is(IRON_ARMOR)
                || stack.is(GOLDEN_ARMOR) || stack.is(DIAMOND_ARMOR) || stack.is(NETHERITE_ARMOR);
    }

    public static double armorPoints(net.minecraft.world.item.ItemStack stack) {
        if (stack.is(LEATHER_ARMOR)) return 3.0D;
        if (stack.is(COPPER_ARMOR)) return 4.0D;
        if (stack.is(IRON_ARMOR)) return 5.0D;
        if (stack.is(GOLDEN_ARMOR)) return 7.0D;
        if (stack.is(DIAMOND_ARMOR)) return 11.0D;
        if (stack.is(NETHERITE_ARMOR)) return 15.0D;
        return 0.0D;
    }

    private static Item register(String name, Item.Properties properties) {
        Identifier id = id(name);
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
        return Registry.register(BuiltInRegistries.ITEM, id, new Item(properties.setId(key)));
    }

    private static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(HappyGhastAutoFireball.MOD_ID, path);
    }
}
