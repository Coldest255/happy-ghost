package com.cyrene.happyghast;

import net.minecraft.core.NonNullList;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.animal.happyghast.HappyGhast;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.resources.Identifier;

import java.util.ArrayList;
import java.util.List;

public final class GhastMenu extends AbstractContainerMenu {
    public static final int EQUIPMENT_SLOTS = 2;
    private final HappyGhast ghast;
    private final int ghastId;
    private final Level level;
    private final int storageRows;
    private final int storageStart;
    private final int storageEnd;
    private final GhastStorage storage;

    public GhastMenu(int containerId, Inventory inventory, GhastMenuData data) {
        this(containerId, inventory, data.ghastId(), findGhast(inventory, data.ghastId()), data.storageRows());
    }

    public GhastMenu(int containerId, Inventory inventory, HappyGhast ghast, int storageRows) {
        this(containerId, inventory, ghast == null ? -1 : ghast.getId(), ghast, storageRows);
    }

    private GhastMenu(int containerId, Inventory inventory, int ghastId, HappyGhast ghast, int storageRows) {
        super(ModMenus.GHAST_INVENTORY, containerId);
        this.ghast = ghast;
        this.ghastId = ghastId;
        this.level = inventory.player.level();
        this.storageRows = storageRows == 6 ? 6 : storageRows == 3 ? 3 : 0;
        this.storageStart = EQUIPMENT_SLOTS;
        this.storage = new GhastStorage(this, this.storageRows * 9);
        this.storageEnd = storageStart + storage.getContainerSize();

        GhastEquipment equipment = new GhastEquipment(this);
        addSlot(new Slot(equipment, 0, 8, 18) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return Items.HARNESS.asList().contains(stack.getItem());
            }

            @Override
            public int getMaxStackSize() {
                return 1;
            }

            @Override
            public Identifier getNoItemIcon() {
                return Identifier.withDefaultNamespace("container/slot/saddle");
            }
        });
        addSlot(new Slot(equipment, 1, 8, 40) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return ModItems.isHappyGhastArmor(stack);
            }

            @Override
            public int getMaxStackSize() {
                return 1;
            }

            @Override
            public Identifier getNoItemIcon() {
                return Identifier.withDefaultNamespace("container/slot/horse_armor");
            }
        });

        for (int row = 0; row < this.storageRows; row++) {
            for (int column = 0; column < 9; column++) {
                addSlot(new Slot(storage, row * 9 + column, 80 + column * 18, 17 + row * 18));
            }
        }

        int playerInventoryY = this.storageRows == 6 ? 138 : 84;
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                addSlot(new Slot(inventory, column + row * 9 + 9,
                        8 + column * 18, playerInventoryY + row * 18));
            }
        }
        for (int column = 0; column < 9; column++) {
            addSlot(new Slot(inventory, column, 8 + column * 18, playerInventoryY + 58));
        }
    }

    private static HappyGhast findGhast(Inventory inventory, int entityId) {
        if (inventory.player.level().getEntity(entityId) instanceof HappyGhast ghast) {
            return ghast;
        }
        return null;
    }

    public HappyGhast getGhast() {
        if (ghast != null) return ghast;
        return level.getEntity(ghastId) instanceof HappyGhast nearbyGhast ? nearbyGhast : null;
    }

    public int getStorageRows() {
        return storageRows;
    }

    public Component getDisplayName() {
        return Component.translatable("container.happy_ghast_auto_fireball.storage");
    }

    @Override
    public ItemStack quickMoveStack(Player player, int slotIndex) {
        if (slotIndex < 0 || slotIndex >= slots.size()) {
            return ItemStack.EMPTY;
        }
        Slot slot = slots.get(slotIndex);
        if (!slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getItem();
        ItemStack original = stack.copy();
        int playerStart = storageEnd;
        int playerEnd = slots.size();

        if (slotIndex < storageStart) {
            if (!moveItemStackTo(stack, playerStart, playerEnd, true)) return ItemStack.EMPTY;
        } else if (slotIndex < storageEnd) {
            if (!moveItemStackTo(stack, playerStart, playerEnd, true)) return ItemStack.EMPTY;
        } else if (Items.HARNESS.asList().contains(stack.getItem()) && !getSlot(0).hasItem()) {
            if (!moveItemStackTo(stack, 0, 1, false)) return ItemStack.EMPTY;
        } else if (ModItems.isHappyGhastArmor(stack) && !getSlot(1).hasItem()) {
            if (!moveItemStackTo(stack, 1, 2, false)) return ItemStack.EMPTY;
        } else if (slotIndex < playerStart + 27) {
            if (!moveItemStackTo(stack, playerStart + 27, playerEnd, false)) return ItemStack.EMPTY;
        } else if (!moveItemStackTo(stack, playerStart, playerStart + 27, false)) {
            return ItemStack.EMPTY;
        }

        if (stack.isEmpty()) slot.setByPlayer(ItemStack.EMPTY);
        else slot.setChanged();
        return original;
    }

    @Override
    public boolean stillValid(Player player) {
        HappyGhast mount = getGhast();
        return mount != null && mount.isAlive() && player.distanceToSqr(mount) <= 64.0D;
    }

    private static final class GhastEquipment extends SimpleContainer {
        private final GhastMenu menu;

        private GhastEquipment(GhastMenu menu) {
            super(2);
            this.menu = menu;
        }

        @Override
        public ItemStack getItem(int slot) {
            HappyGhast ghast = menu.getGhast();
            if (ghast == null) return ItemStack.EMPTY;
            return slot == 0 ? ghast.getItemBySlot(EquipmentSlot.BODY)
                    : HappyGhastAutoFireball.getArmor(ghast);
        }

        @Override
        public void setItem(int slot, ItemStack stack) {
            HappyGhast ghast = menu.getGhast();
            if (ghast == null) return;
            if (slot == 0) ghast.setItemSlot(EquipmentSlot.BODY, stack);
            else if (slot == 1) HappyGhastAutoFireball.setArmor(ghast, stack);
            setChanged();
        }

        @Override
        public ItemStack removeItem(int slot, int amount) {
            ItemStack current = getItem(slot);
            if (current.isEmpty() || amount <= 0) return ItemStack.EMPTY;
            ItemStack removed = current.split(amount);
            if (current.isEmpty()) setItem(slot, ItemStack.EMPTY);
            else setChanged();
            return removed;
        }

        @Override
        public ItemStack removeItemNoUpdate(int slot) {
            ItemStack current = getItem(slot);
            setItem(slot, ItemStack.EMPTY);
            return current;
        }

        @Override
        public int getContainerSize() {
            return 2;
        }

        @Override
        public void setChanged() {
        }

        @Override
        public void clearContent() {
            setItem(0, ItemStack.EMPTY);
            setItem(1, ItemStack.EMPTY);
        }
    }

    private static final class GhastStorage extends SimpleContainer {
        private final GhastMenu menu;

        private GhastStorage(GhastMenu menu, int size) {
            super(size);
            this.menu = menu;
            HappyGhast ghast = menu.getGhast();
            if (ghast == null) return;
            List<ItemStack> saved = ghast.getAttachedOrElse(HappyGhastAutoFireball.GHAST_STORAGE, List.of());
            for (int slot = 0; slot < Math.min(size, saved.size()); slot++) {
                super.setItem(slot, saved.get(slot).copy());
            }
        }

        @Override
        public void setChanged() {
            super.setChanged();
            HappyGhast ghast = menu.getGhast();
            if (ghast == null) return;
            List<ItemStack> copy = new ArrayList<>(getContainerSize());
            for (int slot = 0; slot < getContainerSize(); slot++) copy.add(getItem(slot).copy());
            ghast.setAttached(HappyGhastAutoFireball.GHAST_STORAGE, copy);
        }

        @Override
        public boolean stillValid(Player player) {
            HappyGhast ghast = menu.getGhast();
            return ghast != null && ghast.isAlive() && player.distanceToSqr(ghast) <= 64.0D;
        }
    }
}
