package com.cyrene.happyghast;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.menu.v1.ExtendedMenuProvider;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentSyncPredicate;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import com.mojang.serialization.Codec;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.happyghast.HappyGhast;
import net.minecraft.world.entity.monster.Enderman;
import net.minecraft.world.entity.projectile.hurtingprojectile.SmallFireball;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.functions.EnchantRandomlyFunction;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class HappyGhastAutoFireball implements ModInitializer {
    public static final String MOD_ID = "happy_ghast_auto_fireball";
    private static final long SHOT_COOLDOWN_TICKS = 30L;
    private static final double PLAYER_LINK_RANGE = 32.0D;
    private static final double TARGET_RANGE = 64.0D;
    private static final double PROJECTILE_SPEED = 1.65D;
    private static final Map<UUID, Long> LAST_SHOT = new HashMap<>();
    private static final AttachmentType<Integer> CHEST_COUNT = AttachmentRegistry.<Integer>builder()
            .persistent(Codec.INT)
            .syncWith(ByteBufCodecs.VAR_INT, AttachmentSyncPredicate.all())
            .buildAndRegister(id("chest_count"));
    public static final AttachmentType<List<ItemStack>> GHAST_STORAGE = AttachmentRegistry.createPersistent(
            id("ghast_storage"), ItemStack.OPTIONAL_CODEC.listOf());
    private static final AttachmentType<List<ItemStack>> GHAST_ARMOR = AttachmentRegistry.<List<ItemStack>>builder()
            .persistent(ItemStack.OPTIONAL_CODEC.listOf())
            .buildAndRegister(id("ghast_armor"));

    @Override
    public void onInitialize() {
        ModItems.initialize();
        ModMenus.initialize();
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(output -> {
            output.accept(ModItems.CHEST_UPGRADE);
            output.accept(ModItems.LEATHER_ARMOR);
            output.accept(ModItems.COPPER_ARMOR);
            output.accept(ModItems.IRON_ARMOR);
            output.accept(ModItems.GOLDEN_ARMOR);
            output.accept(ModItems.DIAMOND_ARMOR);
            output.accept(ModItems.NETHERITE_ARMOR);
        });
        PayloadTypeRegistry.serverboundPlay().register(OpenGhastStoragePayload.TYPE, OpenGhastStoragePayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(OpenGhastStoragePayload.TYPE, (payload, context) ->
                context.server().execute(() -> {
                    ServerPlayer player = context.player();
                    if (player.getVehicle() instanceof HappyGhast ghast
                            && ghast.getId() == payload.entityId()) {
                        openGhastStorage(player, ghast);
                    }
                }));
        ServerTickEvents.END_LEVEL_TICK.register(HappyGhastAutoFireball::tickWorld);
        ServerLivingEntityEvents.AFTER_DEATH.register((deadEntity, damageSource) -> {
            if (damageSource.getEntity() instanceof HappyGhast killer) {
                killer.heal(2.0F);
            }
        });
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!(entity instanceof HappyGhast ghast) || ghast.isBaby()) {
                if (!world.isClientSide() && entity instanceof HappyGhast baby
                        && player.getItemInHand(hand).is(Items.SNOWBALL)) {
                    baby.heal(2.0F);
                }
                return InteractionResult.PASS;
            }

            ItemStack held = player.getItemInHand(hand);
            if (player.isSecondaryUseActive() && (held.is(ModItems.CHEST_UPGRADE) || held.is(Items.CHEST))) {
                if (!world.isClientSide()) {
                    int installed = ghast.getAttachedOrElse(CHEST_COUNT, 0);
                    if (installed >= 2) {
                        return InteractionResult.FAIL;
                    }
                    ghast.setAttached(CHEST_COUNT, installed + 1);
                    if (!player.getAbilities().instabuild) {
                        held.shrink(1);
                    }
                }
                return InteractionResult.SUCCESS;
            }

            if (player.isSecondaryUseActive() && held.isEmpty()) {
                if (!world.isClientSide() && player instanceof ServerPlayer serverPlayer) {
                    openGhastStorage(serverPlayer, ghast);
                }
                return InteractionResult.SUCCESS;
            }

            if (!world.isClientSide() && held.is(Items.SNOWBALL)) {
                ghast.heal(2.0F);
            }
            return InteractionResult.PASS;
        });
        LootTableEvents.MODIFY.register((key, builder, source, registries) -> {
            if (!key.equals(BuiltInLootTables.PIGLIN_BARTERING)) {
                return;
            }
            var enchantments = registries.lookupOrThrow(Registries.ENCHANTMENT);
            var fastFlightKey = ResourceKey.create(Registries.ENCHANTMENT, id("fast_flight"));
            var fastFlight = enchantments.getOrThrow(fastFlightKey);
            builder.modifyPools(pool -> pool.add(LootItem.lootTableItem(Items.ENCHANTED_BOOK)
                    .setWeight(2)
                    .apply(EnchantRandomlyFunction.randomEnchantment().withEnchantment(fastFlight))));
        });
    }

    public static boolean hasGhastStorage(HappyGhast ghast) {
        return ghast.getAttachedOrElse(CHEST_COUNT, 0) > 0;
    }

    private static void openGhastStorage(ServerPlayer player, HappyGhast ghast) {
        int chestCount = ghast.getAttachedOrElse(CHEST_COUNT, 0);
        int rows = Math.min(chestCount, 2) * 3;
        migrateLegacyArmor(ghast);
        player.openMenu(new ExtendedMenuProvider<GhastMenuData>() {
            @Override
            public GhastMenu createMenu(int containerId, Inventory inventory, Player viewer) {
                return new GhastMenu(containerId, inventory, ghast, rows);
            }

            @Override
            public Component getDisplayName() {
                return Component.translatable("container.happy_ghast_auto_fireball.storage");
            }

            @Override
            public GhastMenuData getScreenOpeningData(ServerPlayer viewer) {
                return new GhastMenuData(ghast.getId(), rows);
            }
        });
    }

    private static void migrateLegacyArmor(HappyGhast ghast) {
        ItemStack bodyItem = ghast.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.BODY);
        if (ModItems.isHappyGhastArmor(bodyItem) && getArmor(ghast).isEmpty()) {
            setArmor(ghast, bodyItem.copy());
            ghast.setItemSlot(net.minecraft.world.entity.EquipmentSlot.BODY, ItemStack.EMPTY);
        }
    }

    public static ItemStack getArmor(HappyGhast ghast) {
        if (ghast == null) return ItemStack.EMPTY;
        List<ItemStack> armor = ghast.getAttachedOrElse(GHAST_ARMOR, List.of());
        return armor.isEmpty() ? ItemStack.EMPTY : armor.getFirst();
    }

    public static void setArmor(HappyGhast ghast, ItemStack stack) {
        if (ghast != null) ghast.setAttached(GHAST_ARMOR,
                stack.isEmpty() ? List.of() : List.of(stack.copy()));
    }

    public static int getFastFlightLevel(HappyGhast ghast) {
        ItemEnchantments enchantments = getArmor(ghast).getEnchantments();
        ResourceKey<Enchantment> fastFlightKey = ResourceKey.create(Registries.ENCHANTMENT, id("fast_flight"));
        for (Holder<Enchantment> enchantment : enchantments.keySet()) {
            if (enchantment.is(fastFlightKey)) {
                return enchantments.getLevel(enchantment);
            }
        }
        return 0;
    }

    private static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    private static void tickWorld(ServerLevel world) {
        long now = world.getGameTime();

        for (Entity entity : world.getAllEntities()) {
            if (!(entity instanceof HappyGhast ghast) || !ghast.isAlive()) {
                continue;
            }

            Player player = findLinkedPlayer(world, ghast);
            if (player == null) {
                continue;
            }

            LivingEntity target = chooseTarget(player, ghast);
            if (target == null) {
                continue;
            }

            long lastShot = LAST_SHOT.getOrDefault(ghast.getUUID(), Long.MIN_VALUE / 2);
            if (now - lastShot < SHOT_COOLDOWN_TICKS) {
                continue;
            }

            fireSafeProjectile(world, ghast, target);
            LAST_SHOT.put(ghast.getUUID(), now);
        }

        // Prevent the cooldown table from growing forever as ghasts are removed.
        if (LAST_SHOT.size() > 4096) {
            LAST_SHOT.entrySet().removeIf(entry -> now - entry.getValue() > 12000L);
        }
    }

    private static Player findLinkedPlayer(ServerLevel world, HappyGhast ghast) {
        Entity controller = ghast.getControllingPassenger();
        if (controller instanceof Player player && player.isAlive()) {
            return player;
        }
        return world.getNearestPlayer(ghast, PLAYER_LINK_RANGE);
    }

    private static LivingEntity chooseTarget(Player player, HappyGhast ghast) {
        // Prefer the mob the player most recently attacked.
        LivingEntity target = player.getLastHurtMob();
        if (!isValidTarget(target, ghast)) {
            // Otherwise retaliate against the mob that most recently hurt the player.
            target = player.getLastHurtByMob();
        }
        return isValidTarget(target, ghast) ? target : null;
    }

    private static boolean isValidTarget(LivingEntity target, HappyGhast ghast) {
        return target != null
                && target.isAlive()
                && !(target instanceof Player)
                && !(target instanceof Enderman)
                && target != ghast
                && !target.isAlliedTo(ghast)
                && target.distanceToSqr(ghast) <= TARGET_RANGE * TARGET_RANGE;
    }

    private static void fireSafeProjectile(ServerLevel world, HappyGhast ghast, LivingEntity target) {
        // Use the vanilla small-fireball model/particles, but intercept both impact
        // callbacks in the mixin so the vanilla fire placement and damage are bypassed.
        Vec3 spawnPosition = new Vec3(ghast.getX(), ghast.getY() + 1.2D, ghast.getZ());
        Vec3 targetPosition = target.position().add(0.0D, target.getBbHeight() * 0.5D, 0.0D);
        Vec3 direction = targetPosition.subtract(spawnPosition).normalize().scale(PROJECTILE_SPEED);
        SmallFireball projectile = new SmallFireball(world, ghast, direction);
        projectile.setPos(spawnPosition);
        world.addFreshEntity(projectile);
    }
}
