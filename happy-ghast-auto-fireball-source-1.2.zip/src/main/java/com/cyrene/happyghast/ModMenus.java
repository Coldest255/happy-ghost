package com.cyrene.happyghast;

import net.fabricmc.fabric.api.menu.v1.ExtendedMenuType;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.inventory.MenuType;

public final class ModMenus {
    public static final MenuType<GhastMenu> GHAST_INVENTORY = Registry.register(
            BuiltInRegistries.MENU,
            Identifier.fromNamespaceAndPath(HappyGhastAutoFireball.MOD_ID, "ghast_inventory"),
            new ExtendedMenuType<>(GhastMenu::new, GhastMenuData.CODEC));

    private ModMenus() {
    }

    public static void initialize() {
        // Referencing the menu type initializes its registry entry.
    }
}
