package com.cyrene.happyghast.client;

import com.cyrene.happyghast.GhastMenu;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Inventory;

public final class GhastInventoryScreen extends AbstractContainerScreen<GhastMenu> {
    private static final Identifier SLOT = Identifier.withDefaultNamespace("container/slot");
    private static final Identifier BACKGROUND_0 = Identifier.fromNamespaceAndPath(
            "happy_ghast_auto_fireball", "textures/gui/ghast_inventory_0.png");
    private static final Identifier BACKGROUND_3 = Identifier.fromNamespaceAndPath(
            "happy_ghast_auto_fireball", "textures/gui/ghast_inventory_3.png");
    private static final Identifier BACKGROUND_6 = Identifier.fromNamespaceAndPath(
            "happy_ghast_auto_fireball", "textures/gui/ghast_inventory_6.png");
    public GhastInventoryScreen(GhastMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title, 250, menu.getStorageRows() == 6 ? 220 : 166);
        this.titleLabelX = 8;
        this.titleLabelY = 6;
        this.inventoryLabelX = 8;
        this.inventoryLabelY = menu.getStorageRows() == 6 ? 126 : 72;
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        int x = leftPos;
        int y = topPos;
        Identifier background = menu.getStorageRows() == 6 ? BACKGROUND_6
                : menu.getStorageRows() == 3 ? BACKGROUND_3 : BACKGROUND_0;
        graphics.blit(RenderPipelines.GUI_TEXTURED, background, x, y, 0.0F, 0.0F,
                imageWidth, imageHeight, imageWidth, imageHeight);

        // Extend the vanilla horse-inventory panel to fit the Happy Ghast's nine-column storage.
        if (menu.getStorageRows() > 0) {
            graphics.blitSprite(RenderPipelines.GUI_TEXTURED,
                    Identifier.withDefaultNamespace("container/horse/chest_slots"),
                    x + 79, y + 17, 162, menu.getStorageRows() * 18);
            for (int row = 0; row < menu.getStorageRows(); row++) {
                for (int column = 0; column < 9; column++) {
                    graphics.blitSprite(RenderPipelines.GUI_TEXTURED, SLOT,
                            x + 80 + column * 18, y + 17 + row * 18, 18, 18);
                }
            }
        }

        int playerInventoryY = menu.getStorageRows() == 6 ? 138 : 84;
        for (int row = 0; row < 4; row++) {
            for (int column = 0; column < 9; column++) {
                int slotY = row < 3 ? playerInventoryY + row * 18 : playerInventoryY + 58;
                graphics.blitSprite(RenderPipelines.GUI_TEXTURED, SLOT,
                        x + 8 + column * 18, y + slotY, 18, 18);
            }
        }

        // Match the vanilla horse screen's saddle and body-armor equipment sockets.
        graphics.blitSprite(RenderPipelines.GUI_TEXTURED, SLOT, x + 7, y + 17, 18, 18);
        graphics.blitSprite(RenderPipelines.GUI_TEXTURED, SLOT, x + 7, y + 39, 18, 18);
    }
}
