package com.cyrene.happyghast.client;

import com.cyrene.happyghast.GhastMenu;
import com.cyrene.happyghast.ModMenus;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.gui.screens.MenuScreens;

public final class HappyGhastAutoFireballClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        MenuScreens.register(ModMenus.GHAST_INVENTORY, GhastInventoryScreen::new);
    }
}
