package com.cyrene.happyghast;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public record OpenGhastStoragePayload(int entityId) implements CustomPacketPayload {
    public static final Type<OpenGhastStoragePayload> TYPE = new Type<>(
            Identifier.fromNamespaceAndPath(HappyGhastAutoFireball.MOD_ID, "open_ghast_storage"));
    public static final StreamCodec<RegistryFriendlyByteBuf, OpenGhastStoragePayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.VAR_INT, OpenGhastStoragePayload::entityId, OpenGhastStoragePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
