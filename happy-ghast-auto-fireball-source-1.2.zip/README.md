# 更好的乐魂 (Better Happy Ghast)

Minecraft 26.3 / Fabric mod, version 1.2.

## Features

- Baby Happy Ghasts can attack the mob their nearby rider recently attacked or the mob that attacked that rider. Grown Happy Ghasts keep attacking and also unlock armor and storage features. They do not target Endermen.
- Snowballs heal a Happy Ghast, and a Happy Ghast recovers health after a kill.
- Happy Ghast fireballs deal 5 damage, ignite living targets for five seconds, and never ignite or break blocks.
- Phantoms cannot target Happy Ghasts.
- Crouch-use a vanilla chest or the Happy Ghast Chest item on an adult Happy Ghast to install storage, up to two chests. While riding an adult with storage, press the normal inventory key (E) to open it. One chest gives 27 slots; two give 54. You can also crouch-use the Ghast with an empty hand while looking at it.
- Use a Happy Ghast armor item on an adult to equip it. Available armor materials are leather, copper, iron, gold, diamond, and netherite. The armor has no durability and supports Protection and Fast Flight.
- Fast Flight has two levels: level I adds 100% movement speed, and level II adds 200%. It can appear at the enchanting table, from piglin bartering, and as a level-five librarian trade.

## Recipes

All armor recipes use this shape:

```text
material material material
(empty)  (empty)  (empty)
leather  (empty)  leather
```

The chest upgrade uses the requested iron-ingot shape:

```text
iron iron iron
(empty) (empty) (empty)
iron (empty) iron
```

## Build

Build with Java 25 and Gradle 9.9.1. Make sure `JAVA_HOME` points to a Java 25 JDK and Gradle 9.9.1 is available on `PATH`, then run:

```powershell
$env:Path = "$env:JAVA_HOME\bin;$env:Path"
gradle build
```

The mod JAR is generated under `build/libs`.
